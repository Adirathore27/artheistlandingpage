self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6c041044ee1cf738054427848f7a1a87",
    "url": "/Artheist/index.html"
  },
  {
    "revision": "e44bc1f2da2ef5fb80e1",
    "url": "/Artheist/static/css/main.e7aaedd6.chunk.css"
  },
  {
    "revision": "294b8f2c8d3dc886a53c",
    "url": "/Artheist/static/js/2.2505998b.chunk.js"
  },
  {
    "revision": "8aea8f14254a0f15e5ef6812d2273bdf",
    "url": "/Artheist/static/js/2.2505998b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e44bc1f2da2ef5fb80e1",
    "url": "/Artheist/static/js/main.33b35939.chunk.js"
  },
  {
    "revision": "69832da7b0fcf444b1dd",
    "url": "/Artheist/static/js/runtime-main.90df695b.js"
  },
  {
    "revision": "8af7687e47daf3a67fbfb3658cb3d309",
    "url": "/Artheist/static/media/aditya2.8af7687e.jpeg"
  },
  {
    "revision": "cffd398d33c84c4fdf7ea277c5892165",
    "url": "/Artheist/static/media/arpit.cffd398d.jpg"
  },
  {
    "revision": "588ba319e9467b0c8ae78b6f3ef17842",
    "url": "/Artheist/static/media/art.588ba319.svg"
  },
  {
    "revision": "2ea34b77c9cf3be28b3f49eb9f9a063f",
    "url": "/Artheist/static/media/artHeist_logo.2ea34b77.png"
  },
  {
    "revision": "b45c90d43df9311b023d278f5bea4bc1",
    "url": "/Artheist/static/media/ashu3.b45c90d4.jpg"
  },
  {
    "revision": "645a4f888ee10e11763e958f8ec1aca1",
    "url": "/Artheist/static/media/bg11.645a4f88.jpeg"
  },
  {
    "revision": "5db6559fa3d35b0dbc10f4c196a9e853",
    "url": "/Artheist/static/media/curtainL.5db6559f.png"
  },
  {
    "revision": "07f173cf8ec15e7149484ec6e7d77130",
    "url": "/Artheist/static/media/curtainR.07f173cf.png"
  },
  {
    "revision": "9aeef801a63fa1510db94e62c81c1130",
    "url": "/Artheist/static/media/dance.9aeef801.jpg"
  },
  {
    "revision": "0ba8533e1fd9539c001ce9455ab8e909",
    "url": "/Artheist/static/media/fashion.0ba8533e.svg"
  },
  {
    "revision": "3639e7eff6653acdee926ef2f1128ccd",
    "url": "/Artheist/static/media/gymnast.3639e7ef.svg"
  },
  {
    "revision": "c718bc574c45cd2f671b7c144e3c74d2",
    "url": "/Artheist/static/media/login.c718bc57.png"
  },
  {
    "revision": "3a447d98f54066e1fce498aec50e09c2",
    "url": "/Artheist/static/media/me2.3a447d98.jpeg"
  },
  {
    "revision": "f432d48177c614c9f34a943a280d1789",
    "url": "/Artheist/static/media/up-broken-line-arrow.f432d481.svg"
  }
]);